$(document).ready(function(){

    $(".container1 img").click( function(){
        $('.container1 img').attr('src', 'cat0.png');

    })

    $(".container2 img").click( function(){
        $('.container2 img').attr ('src', 'cat1.png');
    })

    $(".container3 img").click( function(){
        $('.container3 img').attr ('src', 'cat2.png');
    })

    $(".container4 img").click( function(){
        $('.container4  img').attr ('src', 'cat3.png');
    })

    $(".container5 img").click( function(){
        $('.container5 img').attr ('src', 'cat4.png');
    })
});